package Apotik;

public class Apotik {
    
    public static void main(String[] args) {
        formutama start = new formutama();
        start.setVisible(true);
    }
    
}
